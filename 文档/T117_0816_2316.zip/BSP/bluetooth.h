#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H

#include "stm32f0xx_hal.h"
#include <stdio.h>
#include <string.h>

// 蓝牙状态枚举
typedef enum {
    BT_STATUS_DISCONNECTED = 0,
    BT_STATUS_CONNECTED,
    BT_STATUS_INITIALIZING,
    BT_STATUS_INIT_FAILED
} Bluetooth_Status;

// 函数声明
void Bluetooth_Init(void);
void Bluetooth_CheckStatus(void);
void Bluetooth_SendData(char* data);
void Bluetooth_SendTemperature(float temperature);
Bluetooth_Status Bluetooth_GetStatus(void);
void Bluetooth_DisplayStatus(void);

#endif /* __BLUETOOTH_H */
