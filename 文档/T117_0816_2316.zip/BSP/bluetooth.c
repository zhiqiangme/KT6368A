#include "bluetooth.h"
#include "KT6368A.h"
#include "oled.h"
#include "delay.h"
#include "usart.h"

// 全局变量
static Bluetooth_Status btStatus = BT_STATUS_DISCONNECTED;
static uint32_t lastReconnectTime = 0;

/**
 * @brief 蓝牙初始化函数 - 带超时保护
 */
void Bluetooth_Init(void)
{
    OLED_ShowString(2, 1, "BT Init...      ");
    delay_ms(500);
    
    btStatus = BT_STATUS_INITIALIZING;
    
    // 添加超时保护的AT测试
    uint32_t startTime = HAL_GetTick();
    
    // 清空接收缓冲区
    g_recv_complete_flag = 0;
    g_recv_length = 0;
    
    // 发送AT指令测试
    usart2_send_string((uint8_t *)"AT\r\n");
    delay_ms(100);
    
    // 等待响应，最多等待500ms
    while(HAL_GetTick() - startTime < 500)
    {
        if(g_recv_complete_flag == 1)
        {
            g_recv_complete_flag = 0;
            g_recv_length = 0;
            btStatus = BT_STATUS_CONNECTED;
            OLED_ShowString(2, 1, "BT Connected    ");
            return;
        }
        delay_ms(10);
    }
    
    // 如果没有响应，标记为初始化失败但不阻塞
    btStatus = BT_STATUS_INIT_FAILED;
    OLED_ShowString(2, 1, "BT Init Failed  ");
}

/**
 * @brief 检查蓝牙连接状态 - 安全版本
 */
void Bluetooth_CheckStatus(void)
{
    // 添加异常处理，避免函数卡死
    static uint32_t checkStartTime = 0;
    checkStartTime = HAL_GetTick();
    
    // 限制检查时间，避免长时间阻塞
    if(HAL_GetTick() - checkStartTime > 1000)
    {
        return;
    }
    
    // 只在连接和断开状态下检查
    if(btStatus == BT_STATUS_CONNECTED || btStatus == BT_STATUS_DISCONNECTED)
    {
        // 快速检查，添加超时
        uint32_t quickStart = HAL_GetTick();
        while(HAL_GetTick() - quickStart < 200)  // 最多等待200ms
        {
            if(KT6368A_GetStatus() == 1)
            {
                if(btStatus != BT_STATUS_CONNECTED)
                {
                    btStatus = BT_STATUS_CONNECTED;
                    OLED_ShowString(2, 1, "BT Connected    ");
                }
                return;
            }
            delay_ms(10);
        }
        
        // 如果检查失败，标记为断开
        if(btStatus == BT_STATUS_CONNECTED)
        {
            btStatus = BT_STATUS_DISCONNECTED;
            OLED_ShowString(2, 1, "BT Disconnected ");
        }
    }
}

/**
 * @brief 发送字符串数据 - 安全版本
 */
void Bluetooth_SendData(char* data)
{
    // 添加空指针检查和状态检查
    if(data == NULL) return;
    if(btStatus != BT_STATUS_CONNECTED) return;
    
    // 添加超时保护
    g_recv_complete_flag = 0;
    g_recv_length = 0;
    
    KT6368A_SendData(data);
}

/**
 * @brief 发送温度数据 - 安全版本
 */
void Bluetooth_SendTemperature(float temperature)
{
    if(btStatus != BT_STATUS_CONNECTED) return;
    
    char temp_str[32];
    sprintf(temp_str, "%.2f", temperature);
    Bluetooth_SendData(temp_str);
}

/**
 * @brief 获取蓝牙状态
 */
Bluetooth_Status Bluetooth_GetStatus(void)
{
    return btStatus;
}

/**
 * @brief 在OLED上显示蓝牙状态
 */
void Bluetooth_DisplayStatus(void)
{
    // 这个函数现在在main循环中被调用
    // 为了安全，可以添加状态检查
    switch(btStatus)
    {
        case BT_STATUS_CONNECTED:
            OLED_ShowString(2, 1, "BT Connected    ");
            break;
        case BT_STATUS_DISCONNECTED:
            OLED_ShowString(2, 1, "BT Disconnected ");
            break;
        case BT_STATUS_INITIALIZING:
            // 不显示，避免闪烁
            break;
        case BT_STATUS_INIT_FAILED:
            OLED_ShowString(2, 1, "BT Init Failed  ");
            break;
        default:
            // 保持当前显示
            break;
    }
}
