/********************************************************************************
  * 文 件 名: bsp_KT6368A.c
  * 版 本 号: 初版
  * 修改作者: kwin
  * 修改日期: 2023年049月26日
  * 功能介绍:          
  ******************************************************************************
  * 注意事项:
*********************************************************************************/
#include "KT6368A.h"
/************************************************
函数名称 ： IsOK
功    能 ： 测试AT指令是否返回OK
参    数 ： 
返 回 值 ： 1：OK，0：Fail
作    者 ： kwin
*************************************************/
uint8_t IsOK(void)
{
	uint8_t i=0;
	usart2_send_string("AT+QT\r\n");
	while(g_recv_complete_flag==0)
	{
		delay_ms(1);
		i++;
		if(i>200) return 0;		
	}	
	g_recv_complete_flag = 0;                   // 等待下次接收
	g_recv_length = 0;													// 清空长度

	if((g_recv_buff[0]=='Q')&&(g_recv_buff[1]=='T'))
		return 1;
	else 
		return 0;
	
}

/************************************************
函数名称 ： Get_Ver
功    能 ： 获取模块版本号
参    数 ： 
返 回 值 ： 
作    者 ： kwin
*************************************************/
void Get_Ver(void)
{
	uint8_t i=0;
	usart2_send_string("AT+TD\r\n");
	while(g_recv_complete_flag==0)
	{
		delay_ms(1);
		i++;
		if(i>200) return;		
	}	
	g_recv_complete_flag = 0;                   // 等待下次接收
	g_recv_length = 0;													// 清空长度
	printf("\r\n%s",g_recv_buff);
	
}

/************************************************
函数名称 ： Get_Addr
功    能 ： 获取模块MAC地址
参    数 ： 
返 回 值 ： 
作    者 ： kwin
*************************************************/
void Get_Addr(void)
{
	uint8_t i=0;
	usart2_send_string("AT+TN\r\n");
	while(g_recv_complete_flag==0)
	{
		delay_ms(1);
		i++;
		if(i>200) return;		
	}	
	g_recv_complete_flag = 0;                   // 等待下次接收
	g_recv_length = 0;													// 清空长度
	printf("\r\n%s",g_recv_buff);
	
}

/************************************************
函数名称 ： Get_Name
功    能 ： 获取模块名称
参    数 ： 
返 回 值 ： 
作    者 ： kwin
*************************************************/
void Get_Name(void)
{
	uint8_t i=0;
	usart2_send_string("AT+TM\r\n");
	while(g_recv_complete_flag==0)
	{
		delay_ms(1);
		i++;
		if(i>200) return;		
	}	
	g_recv_complete_flag = 0;                   // 等待下次接收
	g_recv_length = 0;													// 清空长度
	printf("\r\n%s",g_recv_buff);
	
}
