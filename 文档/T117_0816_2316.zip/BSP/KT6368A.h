#ifndef _KT6368A_H
#define _KT6368A_H

#include "main.h"

uint8_t IsOK(void);//测试AT指令是否返回OK
void Get_Ver(void);//获取模块版本号
void Get_Addr(void);//获取模块MAC地址
void Get_Name(void);//获取模块名称
#endif  /* _KT6368A_H */
